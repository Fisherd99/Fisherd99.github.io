#!/bin/bash
#SBATCH -p debug
#SBATCH -N 1
#SBATCH --cpus-per-task=48
#SBATCH --ntasks-per-node=1
#SBATCH -J Si
#SBATCH -o abacusjob-%j.log
##SBATCH -e abacusjob-%j.err
##SBATCH --mem=180000

ABACUS_hj=$HOME/deepmodeling/abacus-hj/build/abacus
ABACUS_BSE=$HOME/deepmodeling/abacus-BSE/build/abacus
ABACUS_BSE_debug=$HOME/deepmodeling/abacus-BSE/build_debug/abacus
LibRPA=$HOME/deepmodeling/LibRPA/build/chi0_main.exe
LibRPA_test=$HOME/deepmodeling/LibRPA/build_debug/chi0_main.exe

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
start_time=$(date +%s)
echo Begin Time: `date`
echo Working directory is $PWD
echo This job runs on the following nodes:
echo $SLURM_JOB_NODELIST
echo This job has allocated $SLURM_JOB_CPUS_PER_NODE cpu cores.
echo cpus per task: $SLURM_CPUS_PER_TASK, this should be OMP_NUM_THREADS: $OMP_NUM_THREADS
  rm KS_*
  rm band_*
  rm Cs_*
  rm coulomb_*
  rm -r OUT.scf
  rm -r OUT.nscf

  cp KPT_scf KPT
  cp INPUT_scf INPUT
  mpirun -np 1 $ABACUS_hj > abacusjob-scf.log 2>&1
  rm -f vxc_out
  cp -a OUT.scf/vxc_out.dat vxc_out

  cp KPT_nscf KPT
  cp INPUT_nscf INPUT
  mpirun -np 1 $ABACUS_hj > abacusjob-nscf.log 2>&1
  python preprocess_abacus_for_librpa_band.py -d OUT.nscf

  mpirun -np 1 $LibRPA > librpajob.log 2>&1

  cp INPUT_bse INPUT
  cp KPT_scf KPT
  mpirun -np 1 $ABACUS_BSE > abacusjob-bse.log 2>&1
echo "End Time: `date`"
end_time=$(date +%s)
runtime=$((end_time - start_time))
echo "Job completed. Total runtime: $runtime seconds."