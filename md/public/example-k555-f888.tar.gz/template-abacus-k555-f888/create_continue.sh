#!/bin/bash
#SBATCH -p debug
#SBATCH -N 1
#SBATCH --cpus-per-task=48
#SBATCH --ntasks-per-node=1
#SBATCH -J Si
#SBATCH -o abacusjob-%j.log
##SBATCH -e abacusjob-%j.err
##SBATCH --mem=180000

ABACUS_hj=$HOME/deepmodeling/abacus-hj/build/abacus
ABACUS_BSE=$HOME/deepmodeling/abacus-BSE/build/abacus
ABACUS_BSE_debug=$HOME/deepmodeling/abacus-BSE/build_debug/abacus
LibRPA=$HOME/deepmodeling/LibRPA/build/chi0_main.exe
LibRPA_test=$HOME/deepmodeling/LibRPA/build_debug/chi0_main.exe

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
start_time=$(date +%s)
echo Begin Time: `date`
echo Working directory is $PWD
echo This job runs on the following nodes:
echo $SLURM_JOB_NODELIST
echo This job has allocated $SLURM_JOB_CPUS_PER_NODE cpu cores.
echo cpus per task: $SLURM_CPUS_PER_TASK, this should be OMP_NUM_THREADS: $OMP_NUM_THREADS

  rm band_KS_*
  rm band_vxc_*
  rm -r OUT.nscf

  cp KPT_nscf KPT
  cp INPUT_nscf INPUT
  mpirun -np 1 $ABACUS_hj > abacusjob-nscf.log 2>&1
  python preprocess_abacus_for_librpa_band.py -d OUT.nscf
  # force band_continue = t (replace existing setting)
  sed -i -E 's/^([[:space:]]*band_continue[[:space:]]*=[[:space:]]*).*/\1t/' librpa.in
  mpirun -np 1 $LibRPA > librpajob_c.log 2>&1

  cp INPUT_bse INPUT
  cp KPT_scf KPT
  mpirun -np 1 $ABACUS_BSE > abacusjob-bse_c.log 2>&1
echo "End Time: `date`"
end_time=$(date +%s)
runtime=$((end_time - start_time))
echo "Job completed. Total runtime: $runtime seconds."