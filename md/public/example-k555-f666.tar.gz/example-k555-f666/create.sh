#!/bin/bash
#SBATCH -p debug
#SBATCH -N 1
#SBATCH --cpus-per-task=48
#SBATCH --ntasks-per-node=1
#SBATCH -J Si
#SBATCH -o abacusjob-%j.log
##SBATCH -e abacusjob-%j.err
##SBATCH --mem=180000

ABACUS=$HOME/deepmodeling/abacus-BSE/build/abacus_std_para
ABACUS_debug=$HOME/deepmodeling/abacus-BSE/build_debug/abacus_std_para
LibRPA=$HOME/deepmodeling/LibRPA/build/chi0_main.exe
LibRPA_debug=$HOME/deepmodeling/LibRPA/build_debug/chi0_main.exe

OUT_LIBRPA_DIR="OUT.librpa"

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
start_time=$(date +%s)
echo Begin Time: `date`
echo Working directory is $PWD
echo This job runs on the following nodes:
echo $SLURM_JOB_NODELIST
echo This job has allocated $SLURM_JOB_CPUS_PER_NODE cpu cores.
echo cpus per task: $SLURM_CPUS_PER_TASK, this should be OMP_NUM_THREADS: $OMP_NUM_THREADS
echo "`date`: running scf"
  rm -r $OUT_LIBRPA_DIR
  cp KPT_scf KPT
  cp INPUT_scf INPUT
  mpirun -np 1 $ABACUS > abacusjob-scf.log 2>&1
  cp -a OUT.scf/vxc_out.dat $OUT_LIBRPA_DIR/vxc_out
echo "`date`: running nscf"
  cp KPT_nscf KPT
  cp INPUT_nscf INPUT
  mpirun -np 1 $ABACUS > abacusjob-nscf.log 2>&1
  python preprocess_abacus_for_librpa_band.py -i OUT.nscf -o $OUT_LIBRPA_DIR
echo "`date`: running librpa"
  # force read_sigc_mat_rf = f (replace existing setting)
  sed -i -E 's/^([[:space:]]*read_sigc_mat_rf[[:space:]]*=[[:space:]]*).*/\1f/' librpa.in
  mpirun -np 1 $LibRPA > librpajob.log 2>&1
echo "`date`: running bse"
  cp -a energy_qp KS_band_spin_1.dat GW_band_spin_1.dat $OUT_LIBRPA_DIR
  cp INPUT_bse INPUT
  cp KPT_scf KPT
  mpirun -np 1 $ABACUS > abacusjob-bse.log 2>&1
echo "End Time: `date`"
end_time=$(date +%s)
runtime=$((end_time - start_time))
echo "Job completed. Total runtime: $runtime seconds."