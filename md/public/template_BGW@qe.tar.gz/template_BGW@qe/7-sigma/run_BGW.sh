#!/bin/bash
#SBATCH -p 640
#SBATCH -N 1
#SBATCH --cpus-per-task=48
#SBATCH --ntasks-per-node=1
#SBATCH -J BGW
#SBATCH -o BGWjob-%j.log
##SBATCH -e BGWjob-%j.err
#SBATCH --mem=180000

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
start_time=$(date +%s)
echo Time is `date`
echo Directory is $PWD
echo This job runs on the following nodes:
echo $SLURM_JOB_NODELIST
echo This job has allocated $SLURM_JOB_CPUS_PER_NODE cpu cores.
echo cpus per task: $SLURM_CPUS_PER_TASK, this should be OMP_NUM_THREADS: $OMP_NUM_THREADS

ln -sf ../2-wfn/RHO .
ln -sf ../2-wfn/WFN WFN_inner
ln -sf ../2-wfn/vxc.dat .
ln -sf ../6-epsilon/eps0mat.h5 .
ln -sf ../6-epsilon/epsmat.h5 .

# --- Auto-fill kpoints (3 columns) from kgrid.out
# Set -e is recommended in batch scripts
set -euo pipefail

SIGMA_INP="${SIGMA_INP:-sigma.inp}"
KGRID="${KGRID:-../2-wfn/kgrid.out}"

if [[ ! -f "$KGRID" ]]; then
  echo "[ERROR] kgrid file not found: $KGRID" >&2
  exit 1
fi
if [[ ! -f "$SIGMA_INP" ]]; then
  echo "[ERROR] sigma input not found: $SIGMA_INP" >&2
  exit 1
fi

tmp_k="$(mktemp)"
tmp_inp="$(mktemp)"

awk '
  BEGIN{ inKP=0 }
  /^K_POINTS[[:space:]]+crystal/ { inKP=1; next }
  inKP==1 {
    # skip the count line (single integer)
    if ($1 ~ /^[0-9]+$/ && NF==1) { next }

    # require at least 3 numeric fields
    if (NF < 3) next
    if ($1 !~ /^[-+0-9.]/ || $2 !~ /^[-+0-9.]/ || $3 !~ /^[-+0-9.]/) next

    x=$1+0; y=$2+0; z=$3+0
    printf("  %.9f  %.9f  %.9f  1.0\n", x, y, z)
  }
' "$KGRID" > "$tmp_k"

if [[ ! -s "$tmp_k" ]]; then
  echo "[ERROR] Failed to parse any k-points from $KGRID" >&2
  rm -f "$tmp_k" "$tmp_inp"
  exit 1
fi

# Replace (or create) the kpoints block in sigma.inp (keep other content unchanged)
awk -v kfile="$tmp_k" '
  BEGIN { inblk=0; printed=0 }
  /^[[:space:]]*begin[[:space:]]+kpoints[[:space:]]*$/ {
    print
    while ((getline line < kfile) > 0) print line
    close(kfile)
    printed=1
    inblk=1
    next
  }
  /^[[:space:]]*end[[:space:]]*$/ {
    if (inblk==1) { print; inblk=0; next }
  }
  { if (inblk==0) print }
  END {
    if (printed==0) {
      print ""
      print "begin kpoints"
      while ((getline line < kfile) > 0) print line
      close(kfile)
      print "end"
    }
  }
' "$SIGMA_INP" > "$tmp_inp"

mv "$tmp_inp" "$SIGMA_INP"
rm -f "$tmp_k"

echo "[INFO] Updated kpoints in $SIGMA_INP from $KGRID (weight=1.0)"
# --- end auto-fill ---

mpirun -n 1 $BGW_dir/sigma.real.x &> sigma.out

end_time=$(date +%s)
runtime=$((end_time - start_time))
echo "Job completed. Total runtime: $runtime seconds."
