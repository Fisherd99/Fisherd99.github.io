#!/bin/bash
#SBATCH -p 640
#SBATCH -N 1
#SBATCH --cpus-per-task=48
#SBATCH --ntasks-per-node=1
#SBATCH -J BGW
#SBATCH -o BGWjob-%j.log
##SBATCH -e BGWjob-%j.err
#SBATCH --mem=180000

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
start_time=$(date +%s)
echo Time is `date`
echo Directory is $PWD
echo This job runs on the following nodes:
echo $SLURM_JOB_NODELIST
echo This job has allocated $SLURM_JOB_CPUS_PER_NODE cpu cores.
echo cpus per task: $SLURM_CPUS_PER_TASK, this should be OMP_NUM_THREADS: $OMP_NUM_THREADS

ln -sf ../1-scf/Si.save .
mpirun -n 1 $BGW_dir/kgrid.x ./kgrid.inp ./kgrid.out ./kgrid.log
# 自动将 kgrid.out 中的 K_POINTS crystal 数据覆盖到 bands.in
awk '/K_POINTS crystal/ {print; exit} !found {print}' bands.in > temp_bands.txt
sed -n '/K_POINTS crystal/,$p' kgrid.out | tail -n +2 >> temp_bands.txt
mv temp_bands.txt bands.in

mpirun -n 1 $qe_dir/pw.x -in bands.in &> bands.out
mpirun -n 1 $qe_dir/pw2bgw.x -in pw2bgw.in &> pw2bgw.out

end_time=$(date +%s)
runtime=$((end_time - start_time))
echo "Job completed. Total runtime: $runtime seconds."
