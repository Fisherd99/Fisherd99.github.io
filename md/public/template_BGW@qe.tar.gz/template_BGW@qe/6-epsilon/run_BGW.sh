#!/bin/bash
#SBATCH -p 640
#SBATCH -N 1
#SBATCH --cpus-per-task=48
#SBATCH --ntasks-per-node=1
#SBATCH -J BGW
#SBATCH -o BGWjob-%j.log
##SBATCH -e BGWjob-%j.err
#SBATCH --mem=180000

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
start_time=$(date +%s)
echo Time is `date`
echo Directory is $PWD
echo This job runs on the following nodes:
echo $SLURM_JOB_NODELIST
echo This job has allocated $SLURM_JOB_CPUS_PER_NODE cpu cores.
echo cpus per task: $SLURM_CPUS_PER_TASK, this should be OMP_NUM_THREADS: $OMP_NUM_THREADS

ln -sf ../2-wfn/WFN WFN
ln -sf ../3-wfnq/WFN WFNq

# --- Auto-fill qpoints in epsilon.inp from ../2-wfn/kgrid.out ---
#   - If a k-point is exactly (0,0,0): write "0 0 0.001  1.0  1"
#   - Otherwise: copy coordinates, set weight=1.0, last column=0
set -euo pipefail

EPS_INP="${EPS_INP:-epsilon.inp}"
KGRID="${KGRID:-../2-wfn/kgrid.out}"
# z value used to replace the Gamma point (0,0,0)
EPS_GAMMA_Z="${EPS_GAMMA_Z:-0.001000000}"
# numerical tolerance to detect (0,0,0)
EPS_ZERO_TOL="${EPS_ZERO_TOL:-1e-12}"

if [[ ! -f "$KGRID" ]]; then
  echo "[ERROR] kgrid file not found: $KGRID" >&2
  exit 1
fi
if [[ ! -f "$EPS_INP" ]]; then
  echo "[ERROR] epsilon input not found: $EPS_INP" >&2
  exit 1
fi

tmp_q="$(mktemp)"
tmp_inp="$(mktemp)"

awk -v gz="$EPS_GAMMA_Z" -v ztol="$EPS_ZERO_TOL" '
  function abs(x){ return x<0 ? -x : x }
  BEGIN{ inKP=0 }
  /^K_POINTS[[:space:]]+crystal/ { inKP=1; next }
  inKP==1 {
    # skip the count line (single integer)
    if ($1 ~ /^[0-9]+$/ && NF==1) { next }

    # require at least 3 numeric fields
    if (NF < 3) next
    if ($1 !~ /^[-+0-9.]/ || $2 !~ /^[-+0-9.]/ || $3 !~ /^[-+0-9.]/) next

    x=$1+0; y=$2+0; z=$3+0

    # If (0,0,0) -> special qpoint with last column 1
    if (abs(x) < ztol && abs(y) < ztol && abs(z) < ztol) {
      printf("  0.000000000  0.000000000  %.9f  1.0  1\n", gz+0.0)
    } else {
      printf("  %.9f  %.9f  %.9f  1.0  0\n", x, y, z)
    }
  }
' "$KGRID" > "$tmp_q"

if [[ ! -s "$tmp_q" ]]; then
  echo "[ERROR] Failed to parse any k-points from $KGRID" >&2
  rm -f "$tmp_q" "$tmp_inp"
  exit 1
fi

# Replace (or create) the qpoints block in epsilon.inp (keep other content unchanged)
awk -v qfile="$tmp_q" '
  BEGIN { inblk=0; printed=0 }
  /^[[:space:]]*begin[[:space:]]+qpoints[[:space:]]*$/ {
    print
    while ((getline line < qfile) > 0) print line
    close(qfile)
    printed=1
    inblk=1
    next
  }
  /^[[:space:]]*end[[:space:]]*$/ {
    if (inblk==1) { print; inblk=0; next }
  }
  { if (inblk==0) print }
  END {
    if (printed==0) {
      print ""
      print "begin qpoints"
      while ((getline line < qfile) > 0) print line
      close(qfile)
      print "end"
    }
  }
' "$EPS_INP" > "$tmp_inp"

mv "$tmp_inp" "$EPS_INP"
rm -f "$tmp_q"

echo "[INFO] Updated qpoints in $EPS_INP from $KGRID (Gamma->z=${EPS_GAMMA_Z}, others flag=0)"
# --- end auto-fill ---

mpirun -n 1 $BGW_dir/epsilon.real.x &> epsilon.out

end_time=$(date +%s)
runtime=$((end_time - start_time))
echo "Job completed. Total runtime: $runtime seconds."
