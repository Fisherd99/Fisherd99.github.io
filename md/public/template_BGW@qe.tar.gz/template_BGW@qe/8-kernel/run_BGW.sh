#!/bin/bash
#SBATCH -p 640
#SBATCH -N 1
#SBATCH --cpus-per-task=48
#SBATCH --ntasks-per-node=1
#SBATCH -J BGW
#SBATCH -o BGWjob-%j.log
##SBATCH -e BGWjob-%j.err
#SBATCH --mem=180000

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
start_time=$(date +%s)
echo Time is `date`
echo Directory is $PWD
echo This job runs on the following nodes:
echo $SLURM_JOB_NODELIST
echo This job has allocated $SLURM_JOB_CPUS_PER_NODE cpu cores.
echo cpus per task: $SLURM_CPUS_PER_TASK, this should be OMP_NUM_THREADS: $OMP_NUM_THREADS

ln -sf ../2-wfn/WFN WFN_co
ln -sf ../6-epsilon/eps0mat.h5 .
ln -sf ../6-epsilon/epsmat.h5 .
mpirun -n 1 $BGW_dir/kernel.real.x -i kernel.inp > kernel.out

end_time=$(date +%s)
runtime=$((end_time - start_time))
echo "Job completed. Total runtime: $runtime seconds."
