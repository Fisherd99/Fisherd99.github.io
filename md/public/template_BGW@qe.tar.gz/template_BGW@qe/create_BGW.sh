#!/bin/bash
#SBATCH -p debug
#SBATCH -N 1
#SBATCH --cpus-per-task=48
#SBATCH --ntasks-per-node=1
#SBATCH -J BGW
#SBATCH -o BGWjob-%j.log
##SBATCH -e BGWjob-%j.err
#SBATCH --mem=180000

cd 1-scf
bash run_qe.sh
cd ../2-wfn
#ln -sf ../1-scf/Si.save .
bash run_BGW.sh
cd ../3-wfnq
#ln -sf ../1-scf/Si.save .
bash run_BGW.sh
cd ../4-wfn_fi
#ln -sf ../1-scf/Si.save .
bash run_BGW.sh
cd ../5-wfnq_fi
#ln -sf ../1-scf/Si.save .
bash run_BGW.sh
cd ../6-epsilon
#ln -sf ../2-wfn/WFN WFN
#ln -sf ../3-wfnq/WFN WFNq
bash run_BGW.sh
cd ../7-sigma
#ln -sf ../2-wfn/RHO.
#ln -sf ../2-wfn/WFN WFN_inner
#ln -sf ../2-wfn/vxc.dat .
#ln -sf ../6-epsilon/eps0mat.h5 .
#ln -sf ../6-epsilon/epsmat.h5 .
bash run_BGW.sh
cd ../8-kernel
#ln -sf ../2-wfn/WFN WFN_co
#ln -sf ../6-epsilon/eps0mat.h5 .
#ln -sf ../6-epsilon/epsmat.h5 .
bash run_BGW.sh
cd ../9-absorption
#ln -sf ../2-wfn/WFN ./WFN_co
#ln -sf ../4-wfn_fi/WFN ./WFN_fi
#ln -sf ../5-wfnq_fi/WFN ./WFNq_fi
#ln -sf ../6-epsilon/eps0mat.h5 .
#ln -sf ../6-epsilon/epsmat.h5 .
#ln -sf ../7-sigma/eqp1.dat eqp_co.dat
#ln -sf ../8-kernel/bsemat.h5 .
bash run_BGW.sh